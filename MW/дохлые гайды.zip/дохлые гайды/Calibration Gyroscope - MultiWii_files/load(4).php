var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

jQuery(function($){$('div.vectorMenu').each(function(){var self=this;$('h5:first a:first',this).click(function(e){$('.menu:first',self).toggleClass('menuForceShow');e.preventDefault();}).focus(function(){$(self).addClass('vectorMenuFocus');}).blur(function(){$(self).removeClass('vectorMenuFocus');});});});;mw.loader.state({"skins.vector":"ready"});

/* cache key: multiwii_com:resourceloader:filter:minify-js:7:0fcba82177db6429d02096ea1f0465ed */


}
/*
     FILE ARCHIVED ON 02:38:19 Apr 18, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 09:41:00 Feb 17, 2022.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 79.53
  exclusion.robots: 0.085
  exclusion.robots.policy: 0.077
  RedisCDXSource: 0.598
  esindex: 0.008
  LoadShardBlock: 57.754 (3)
  PetaboxLoader3.datanode: 76.168 (4)
  CDXLines.iter: 18.324 (3)
  load_resource: 79.724
  PetaboxLoader3.resolve: 48.926
*/