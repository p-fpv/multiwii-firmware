McmEnum = [
    {
        name: 'default_bold.mcm',
        url: 'data/mcm/default_bold.mcm'
    },
    {
        name: 'default_large.mcm',
        url: 'data/mcm/default_large.mcm'
    },
    {
        name: 'default.mcm',
        url: 'data/mcm/default.mcm'
    }

];